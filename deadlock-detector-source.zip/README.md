# Deadlock GPU Detector

Start OBS Virtual Camera with Game Capture. Extract the whole Windows release and run Deadlock Detector.exe. Press Q to quit. To run the source, install requirements.txt and run python detect_camera_gpu.py.
