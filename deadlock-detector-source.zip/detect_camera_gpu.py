"""Run a postprocessed YOLO26 ONNX detector on an AMD GPU using DirectML."""
import argparse
import json
import sys
from collections import Counter
from pathlib import Path
import time

import cv2
import numpy as np
import onnxruntime as ort
from cv2_enumerate_cameras import enumerate_cameras
from runtime_support import LatestFrameCapture, SceneChangeGuard, CameraMotion, single_camera_instance


ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent


def write_status(value):
    path = ROOT / 'camera-status.json'
    temporary = path.with_suffix('.json.tmp')
    try:
        temporary.write_text(json.dumps(value, indent=2))
        temporary.replace(path)
    except OSError:
        # A transient OneDrive/file-reader lock must not stop live inference.
        pass


def overlap(a, b):
    intersection = np.maximum(0, np.minimum(a[2:4], b[2:4]) - np.maximum(a[:2], b[:2]))
    intersection = float(intersection[0] * intersection[1])
    area_a = float(np.prod(np.maximum(0, a[2:4] - a[:2])))
    area_b = float(np.prod(np.maximum(0, b[2:4] - b[:2])))
    return intersection / max(area_a + area_b - intersection, 1e-6)


def enemy_bar_above(frame, box, ally=False):
    """Use a nearby red horizontal bar as evidence; keep the drawn box body-only."""
    x1, y1, x2, y2 = map(float, box[:4])
    width, height = x2 - x1, y2 - y1
    left = max(0, int(x1 - width * .4))
    right = min(frame.shape[1], int(x2 + width * .4))
    top = max(0, int(y1 - height * .8))
    bottom = min(frame.shape[0], int(y1 + height * .05))
    if right <= left or bottom <= top:
        return False
    hsv = cv2.cvtColor(frame[top:bottom, left:right], cv2.COLOR_BGR2HSV)
    if ally:
        red = cv2.inRange(hsv, (0, 0, 180), (179, 90, 255))
    else:
        red = cv2.inRange(hsv, (0, 140, 65), (12, 255, 255))
        red |= cv2.inRange(hsv, (168, 140, 65), (179, 255, 255))
    # Health bars keep a nearly fixed UI height even when the hero is far away.
    # Extract horizontal strokes before measuring components so a bar touching
    # red scenery does not become one large, non-horizontal component.
    minimum_width = max(8, width * .25)
    kernel = np.ones((1, max(6, int(minimum_width))), np.uint8)
    red = cv2.morphologyEx(red, cv2.MORPH_OPEN, kernel)
    maximum_height = max(8, frame.shape[0] * 26 / 1080)
    count, _, stats, _ = cv2.connectedComponentsWithStats(red)
    for bar_x, bar_y, bar_width, bar_height, area in stats[1:count]:
        center_x = left + bar_x + bar_width / 2
        center_y = top + bar_y + bar_height / 2
        if (bar_width >= minimum_width and bar_width / max(bar_height, 1) >= 3
                and bar_height <= maximum_height and area >= bar_width * bar_height * .45
                and abs(center_x - (x1 + x2) / 2) <= width * .65
                and center_y <= y1):
            return True
    return False


class StableBoxes:
    """Time-based confirmation, motion prediction, and short occlusion handling."""
    def __init__(self, start_confidence=0.35):
        self.start_confidence = start_confidence
        self.tracks = []
        self.next_id = 1
        self.visible_tracks = []

    def reset(self):
        self.tracks.clear()
        self.visible_tracks.clear()

    @staticmethod
    def predict(track, now):
        elapsed = np.clip(now - track['last_seen'], 0, .18)
        displacement = track['velocity'] * elapsed
        return track['box'] + np.array([*displacement, *displacement], np.float32)

    @staticmethod
    def appearance(frame, box):
        if frame is None:
            return None
        x1,y1,x2,y2 = map(float, box[:4])
        width,height=x2-x1,y2-y1
        left,right=max(0,int(x1+width*.2)),min(frame.shape[1],int(x2-width*.2))
        top,bottom=max(0,int(y1+height*.1)),min(frame.shape[0],int(y2-height*.15))
        if right-left < 5 or bottom-top < 8:
            return None
        crop=cv2.resize(frame[top:bottom,left:right],(24,40))
        hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV)
        histogram=cv2.calcHist([hsv],[0,1],None,[16,8],[0,180,0,256])
        brightness=cv2.calcHist([hsv],[2],None,[8],[0,256])
        cv2.normalize(histogram,histogram,norm_type=cv2.NORM_L1)
        cv2.normalize(brightness,brightness,norm_type=cv2.NORM_L1)
        return np.concatenate([histogram.ravel()*.7,brightness.ravel()*.3]).astype(np.float32)

    def move_camera(self, matrix):
        if matrix is None:
            return
        for track in self.tracks:
            for key in ['box','measurement']:
                x1,y1,x2,y2=track[key]
                points=np.array([[x1,y1],[x2,y1],[x1,y2],[x2,y2]],np.float32)
                points=points @ matrix[:,:2].T+matrix[:,2]
                track[key]=np.r_[points.min(axis=0),points.max(axis=0)]
            track['velocity']=matrix[:,:2] @ track['velocity']

    def update(self, rows, now, evidence=None, frame=None, camera_motion=None):
        if evidence is None:
            evidence = [True] * len(rows)
        self.move_camera(camera_motion)
        appearances = [self.appearance(frame,row) for row in rows]
        # Expire old tracks before matching, so a later enemy cannot inherit a
        # confirmed identity after a long capture pause.
        self.tracks = [track for track in self.tracks if now - track['last_seen'] <= (
            .9 if track['confirmed'] and track.get('appearance') is not None else .22)]
        matched_rows = set()
        matched_tracks = set()
        candidates = []
        for ti, track in enumerate(self.tracks):
            predicted = self.predict(track, now)
            center = (predicted[:2] + predicted[2:4]) / 2
            dimensions = np.maximum(predicted[2:4] - predicted[:2], 1)
            diagonal = float(np.linalg.norm(dimensions))
            for ri, row in enumerate(rows):
                iou = overlap(predicted, row[:4])
                other_center = (row[:2] + row[2:4]) / 2
                distance = float(np.linalg.norm(other_center - center)) / max(diagonal, 1)
                other_size = np.maximum(row[2:4] - row[:2], 1)
                ratio = float(np.max(np.maximum(other_size / dimensions, dimensions / other_size)))
                appearance_distance = None
                if track.get('appearance') is not None and appearances[ri] is not None:
                    appearance_distance = cv2.compareHist(track['appearance'],appearances[ri],cv2.HISTCMP_BHATTACHARYYA)
                dormant = now - track['last_seen'] > .22
                if dormant:
                    allowed = (evidence[ri] and ratio < 1.6 and appearance_distance is not None and appearance_distance < .35
                               and distance < (1.2 if camera_motion is not None else .8))
                else:
                    allowed = iou >= .1 or (track['confirmed'] and distance < .65)
                    if appearance_distance is not None and appearance_distance > .75:
                        allowed = False
                if ratio <= 2.5 and allowed:
                    appearance_score = 0 if appearance_distance is None else .15*(1-appearance_distance)
                    candidates.append((.7 * iou + .3 * max(0, 1 - distance)+appearance_score, ti, ri))
        for _, ti, ri in sorted(candidates, reverse=True):
            if ti in matched_tracks or ri in matched_rows:
                continue
            track, row = self.tracks[ti], rows[ri]
            predicted = self.predict(track, now)
            old_center = (track['measurement'][:2] + track['measurement'][2:4]) / 2
            new_center = (row[:2] + row[2:4]) / 2
            elapsed = max(.008, now - track['last_seen'])
            velocity = (new_center - old_center) / elapsed
            speed_limit = max(200, float(np.linalg.norm(row[2:4] - row[:2])) * 12)
            speed = float(np.linalg.norm(velocity))
            if speed > speed_limit:
                velocity *= speed_limit / speed
            track['velocity'] = .55 * velocity + .45 * track['velocity']
            movement = float(np.linalg.norm(new_center - (predicted[:2] + predicted[2:4]) / 2))
            diagonal = max(1, float(np.linalg.norm(row[2:4] - row[:2])))
            weight = min(.9, .55 + movement / diagonal)
            track['box'] = weight * row[:4] + (1 - weight) * predicted
            track['measurement'] = row[:4].copy()
            if appearances[ri] is not None:
                prior=track.get('appearance')
                track['appearance']=appearances[ri] if prior is None else .8*prior+.2*appearances[ri]
            track['score'] = float(row[4])
            track['hits'] += 1
            track['high_hits'] += int(row[4] >= self.start_confidence and evidence[ri])
            track['last_seen'] = now
            track['misses'] = 0
            track['confirmed'] = track['confirmed'] or (
                track['hits'] >= 2 and track['high_hits'] >= 2 and now - track['created'] >= .05)
            matched_tracks.add(ti)
            matched_rows.add(ri)
        for ti, track in enumerate(self.tracks):
            if ti not in matched_tracks:
                track['misses'] += 1
                track['hits'] = 0
                if not track['confirmed']:
                    track['high_hits'] = 0
                    track['created'] = now
        self.tracks = [track for track in self.tracks if now - track['last_seen'] <= (
                           .9 if track['confirmed'] and track.get('appearance') is not None else .22)
                       and (track['confirmed'] or track['misses'] == 0)]
        for ri, row in enumerate(rows):
            if ri not in matched_rows and row[4] >= self.start_confidence and evidence[ri]:
                self.tracks.append({'box': row[:4].copy(), 'measurement': row[:4].copy(),
                                    'velocity': np.zeros(2, np.float32), 'score': float(row[4]),
                                    'hits': 1, 'high_hits': 1, 'last_seen': now,
                                    'created': now, 'id': self.next_id,
                                    'misses': 0, 'confirmed': False})
                self.tracks[-1]['appearance'] = appearances[ri]
                self.next_id += 1
        self.visible_tracks = [track for track in self.tracks
                               if track['confirmed'] and now - track['last_seen'] <= .18]
        return [np.r_[self.predict(track, now), track['score'], 0]
                for track in self.visible_tracks]


def deduplicate(rows, evidence, threshold=.55):
    order = sorted(range(len(rows)), key=lambda i: (not evidence[i], -rows[i, 4]))
    keep = []
    for index in order:
        if not any(overlap(rows[index, :4], rows[other, :4]) > threshold for other in keep):
            keep.append(index)
    return rows[keep], [evidence[index] for index in keep]


def prepare(frame, size):
    height, width = frame.shape[:2]
    gain = min(size / width, size / height)
    resized_width, resized_height = round(width * gain), round(height * gain)
    left = (size - resized_width) // 2
    top = (size - resized_height) // 2
    canvas = np.full((size, size, 3), 114, dtype=np.uint8)
    canvas[top:top + resized_height, left:left + resized_width] = cv2.resize(
        frame, (resized_width, resized_height))
    tensor = np.ascontiguousarray(canvas[:, :, ::-1].transpose(2, 0, 1)[None],
                                dtype=np.float32) / 255.0
    return tensor, gain, left, top


def decode(outputs, gain, left, top, shape, confidence):
    predictions = outputs[0]
    if predictions.ndim != 3 or predictions.shape[0] != 1 or predictions.shape[-1] != 6:
        raise RuntimeError(
            f'Expected postprocessed YOLO26 output [1, N, 6], got {predictions.shape}. '
            'Re-export the model using export_model.py.')
    rows = predictions[0]
    rows = rows[np.isfinite(rows).all(axis=1) & (rows[:, 4] >= confidence)
                & np.isin(rows[:, 5], [0, 1])].copy()
    rows[:, [0, 2]] = (rows[:, [0, 2]] - left) / gain
    rows[:, [1, 3]] = (rows[:, [1, 3]] - top) / gain
    rows[:, [0, 2]] = rows[:, [0, 2]].clip(0, shape[1] - 1)
    rows[:, [1, 3]] = rows[:, [1, 3]].clip(0, shape[0] - 1)
    return rows[(rows[:, 2] > rows[:, 0]) & (rows[:, 3] > rows[:, 1])]


def make_session(model, adapter=0, profile=False):
    if 'DmlExecutionProvider' not in ort.get_available_providers():
        raise RuntimeError('DirectML is missing. Use the supplied GPU Python environment.')
    options = ort.SessionOptions()
    options.enable_mem_pattern = False
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    options.intra_op_num_threads = 1
    options.inter_op_num_threads = 1
    options.add_session_config_entry('session.intra_op.allow_spinning', '0')
    options.enable_profiling = profile
    options.profile_file_prefix = str(ROOT / 'detector-profile')
    session = ort.InferenceSession(str(model), sess_options=options,
        providers=[('DmlExecutionProvider', {'device_id': str(adapter)}),
                   'CPUExecutionProvider'])
    if 'DmlExecutionProvider' not in session.get_providers():
        raise RuntimeError('The session did not activate DirectML.')
    info = session.get_inputs()[0]
    if info.shape[0:2] != [1, 3] or not isinstance(info.shape[2], int) or info.shape[2] != info.shape[3]:
        raise RuntimeError(f'Expected fixed [1, 3, size, size] model input, got {info.shape}')
    return session, info.name, info.shape[2]


def benchmark(model, image, adapter):
    frame = cv2.imread(str(image))
    if frame is None:
        raise RuntimeError(f'Cannot read test image: {image}')
    gpu, name, size = make_session(model, adapter, profile=True)
    tensor, gain, left, top = prepare(frame, size)
    for _ in range(3):
        gpu.run(None, {name: tensor})
    timings = []
    for _ in range(15):
        start = time.perf_counter()
        output = gpu.run(None, {name: tensor})
        timings.append((time.perf_counter() - start) * 1000)
    profile_path = Path(gpu.end_profiling())
    events = json.loads(profile_path.read_text())
    providers = Counter(event.get('args', {}).get('provider') for event in events
                        if event.get('args', {}).get('provider'))
    if not providers.get('DmlExecutionProvider'):
        raise RuntimeError('Model execution profile did not contain GPU nodes.')
    cpu = ort.InferenceSession(str(model), providers=['CPUExecutionProvider'])
    for _ in range(2):
        cpu.run(None, {name: tensor})
    cpu_times = []
    for _ in range(5):
        start = time.perf_counter()
        cpu.run(None, {name: tensor})
        cpu_times.append((time.perf_counter() - start) * 1000)
    rows = decode(output, gain, left, top, frame.shape, 0.35)
    report = {'model': str(model), 'gpu_adapter_index': adapter,
              'profiled_node_providers': dict(providers),
              'gpu_median_ms': float(np.median(timings)),
              'cpu_median_ms': float(np.median(cpu_times)),
              'output_shape': list(output[0].shape), 'detections': len(rows),
              'profile': str(profile_path)}
    (ROOT / 'detector-benchmark.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


def main():
    cv2.setNumThreads(2)
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=Path, default=ROOT / 'best.onnx')
    parser.add_argument('--camera', type=int, default=None,
                        help='Explicit index; otherwise select OBS Virtual Camera by name.')
    parser.add_argument('--adapter', type=int, default=0)
    parser.add_argument('--confidence', type=float, default=0.50,
                        help='Minimum confidence to start an enemy track; default 0.50.')
    parser.add_argument('--ally-confidence', type=float, default=0.35,
                        help='Minimum confidence to start an ally track; default 0.35.')
    parser.add_argument('--track-confidence', type=float, default=0.20)
    parser.add_argument('--allow-no-healthbar', action='store_true',
                        help='Allow new tracks without red-bar confirmation (more false-positive risk).')
    parser.add_argument('--hide-allies', action='store_true', help='Display enemies only.')
    parser.add_argument('--raw-boxes', action='store_true', help='Disable temporal smoothing for diagnosis.')
    parser.add_argument('--video', type=Path)
    parser.add_argument('--benchmark-image', type=Path)
    parser.add_argument('--max-fps', type=float, default=30,
                        help='Preview/inference limit; default matches the current 30 FPS OBS output.')
    parser.add_argument('--max-frames', type=int, default=0,
                        help='Stop after this many frames; zero runs until you quit.')
    args = parser.parse_args()
    if not args.model.is_file():
        raise FileNotFoundError(
            f'Missing trained model: {args.model}\n'
            'Convert your trained best.pt with export_model.py first.')
    if not 0 <= args.confidence <= 1:
        parser.error('Confidence must be between 0 and 1.')
    if not 0 <= args.track_confidence <= args.confidence:
        parser.error('Tracking confidence must be between 0 and the starting confidence.')
    if not args.track_confidence <= args.ally_confidence <= 1:
        parser.error('Ally confidence must be between tracking confidence and 1.')
    if not 1 <= args.max_fps <= 240:
        parser.error('Maximum FPS must be between 1 and 240.')
    if args.benchmark_image:
        benchmark(args.model, args.benchmark_image, args.adapter)
        return
    with single_camera_instance():
        run_camera(args)


def run_camera(args):
    session, name, size = make_session(args.model, args.adapter)
    print(f'GPU inference active: DirectML, adapter {args.adapter}', flush=True)
    if args.video:
        capture = cv2.VideoCapture(str(args.video))
    else:
        index = args.camera
        if index is None:
            choices = [camera for camera in enumerate_cameras(cv2.CAP_DSHOW)
                       if 'obs virtual camera' in camera.name.lower()]
            if not choices:
                raise RuntimeError('OBS Virtual Camera was not found. Open OBS and start its virtual camera.')
            index = choices[0].index
            print(f'Input: {choices[0].name}, camera {index}', flush=True)
        capture = cv2.VideoCapture(index, cv2.CAP_DSHOW)
        capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    if not capture.isOpened():
        capture.release()
        raise RuntimeError('Could not open the camera/video. Close other camera apps or try --camera 0.')
    window = 'Deadlock detector - AMD GPU - Q to quit'
    smooth = None
    stabilizers = {0: StableBoxes(args.confidence), 1: StableBoxes(args.ally_confidence)}
    scene_guard = SceneChangeGuard()
    camera_motion = CameraMotion()
    motion_ms = 0.
    latest = LatestFrameCapture(capture) if not args.video else None
    last_sequence = 0
    dropped_frames = 0
    scene_resets = 0
    frames = 0
    last_health = 0.0
    last_presented = time.perf_counter()
    try:
        cv2.namedWindow(window, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window, 1280, 720)
        while True:
            start = time.perf_counter()
            if latest:
                packet = latest.read(last_sequence)
                ok = packet is not None
                if ok:
                    sequence, captured_at, frame = packet
                    dropped_frames += max(0, sequence - last_sequence - 1)
                    last_sequence = sequence
            else:
                ok, frame = capture.read()
                captured_at = time.monotonic()
            if not ok:
                print('Camera/video stopped supplying frames.', flush=True)
                break
            motion_start=time.perf_counter()
            prior_boxes=[track['box'] for stabilizer in stabilizers.values() for track in stabilizer.tracks]
            motion = camera_motion.update(frame, prior_boxes) if not args.raw_boxes else None
            motion_ms=(time.perf_counter()-motion_start)*1000
            if scene_guard.update(frame, motion):
                for stabilizer in stabilizers.values():
                    stabilizer.reset()
                scene_resets += 1
            tensor, gain, left, top = prepare(frame, size)
            inference_start = time.perf_counter()
            outputs = session.run(None, {name: tensor})
            inference_ms = (time.perf_counter() - inference_start) * 1000
            rows = decode(outputs, gain, left, top, frame.shape,
                          min(args.confidence, args.ally_confidence) if args.raw_boxes else args.track_confidence)
            if args.raw_boxes:
                thresholds = np.where(rows[:, 5] == 1, args.ally_confidence, args.confidence)
                rows = rows[rows[:, 4] >= thresholds]
            raw_count = len(rows)
            if not args.raw_boxes:
                evidence = ([True] * len(rows) if args.allow_no_healthbar else
                            [enemy_bar_above(frame, row[:4], ally=int(row[5]) == 1) for row in rows])
                rows, evidence = deduplicate(rows, evidence)
                tracked_rows, visible_tracks = [], []
                for class_id, stabilizer in stabilizers.items():
                    indexes = [i for i, row in enumerate(rows) if int(row[5]) == class_id]
                    updated = stabilizer.update(rows[indexes], time.monotonic(), [evidence[i] for i in indexes],
                                                frame=frame,camera_motion=motion)
                    for row in updated:
                        row[5] = class_id
                    tracked_rows.extend(updated)
                    visible_tracks.extend(stabilizer.visible_tracks)
                rows = tracked_rows
            for index, (x1, y1, x2, y2, score, _) in enumerate(rows):
                a, b, c, d = map(int, (x1, y1, x2, y2))
                class_id = int(rows[index][5])
                if class_id == 1 and args.hide_allies:
                    continue
                track = visible_tracks[index] if not args.raw_boxes else None
                coasting = track is not None and track['misses'] > 0
                color = (0, 190, 255) if coasting else ((255, 210, 50) if class_id else (40, 140, 255))
                kind = 'Ally' if class_id else 'Enemy'
                label = f'{kind} {track["id"]} tracking' if coasting else (
                    f'{kind} {track["id"]} {score:.0%}' if track else f'{kind} {score:.0%}')
                cv2.rectangle(frame, (a, b), (c, d), color, 2)
                cv2.putText(frame, label, (max(0, a), max(20, b - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            presented_at = time.perf_counter()
            fps = 1 / max(presented_at - last_presented, 1e-6)
            last_presented = presented_at
            smooth = fps if smooth is None else 0.9 * smooth + 0.1 * fps
            frames += 1
            if frames == 1:
                print(f'Camera streaming: {frame.shape[1]}x{frame.shape[0]}, first GPU detection complete.', flush=True)
            if time.monotonic() - last_health >= 5:
                write_status({
                    'status': 'running', 'model': str(args.model.resolve()),
                    'provider': 'DmlExecutionProvider', 'adapter': args.adapter,
                    'frames_processed': frames, 'processing_fps': round(smooth, 1),
                    'inference_ms': round(inference_ms, 2),
                    'camera_motion_ms': round(motion_ms,2),
                    'camera_motion_quality': round(camera_motion.last_quality,3),
                    'read_to_result_ms': round((time.monotonic() - captured_at) * 1000, 2),
                    'raw_detections': raw_count, 'stable_tracks': len(rows),
                    'discarded_old_frames': dropped_frames, 'scene_resets': scene_resets,
                    'max_fps': args.max_fps, 'updated_unix': time.time()})
                last_health = time.monotonic()
            cv2.putText(frame, f'AMD GPU | {smooth:.1f} FPS | inference {inference_ms:.1f} ms',
                        (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
            if not args.raw_boxes:
                cv2.putText(frame, 'Orange: enemy | Cyan: ally | IDs are tracks, not totals | Q: quit',
                            (15, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, .55,
                            (255, 255, 255), 1)
            cv2.imshow(window, frame)
            if args.max_frames > 0 and frames >= args.max_frames:
                break
            wait_ms = max(1, round((1 / args.max_fps - (time.perf_counter() - start)) * 1000))
            if cv2.waitKey(wait_ms) & 0xff in (ord('q'), ord('Q'), 27):
                break
            if cv2.getWindowProperty(window, cv2.WND_PROP_VISIBLE) < 1:
                break
    finally:
        if latest:
            latest.close()
        else:
            capture.release()
        cv2.destroyAllWindows()
        write_status({
            'status': 'stopped', 'frames_processed': frames,
            'updated_unix': time.time()})


if __name__ == '__main__':
    main()
