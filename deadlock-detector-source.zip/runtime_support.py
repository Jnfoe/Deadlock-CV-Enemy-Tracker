"""Camera freshness, scene-change detection, and single-instance control."""
from contextlib import contextmanager
import ctypes
import os
import threading
import time

import cv2
import numpy as np


class LatestFrameCapture:
    """Continuously read a live camera, retaining only its newest frame."""
    def __init__(self, capture):
        self.capture = capture
        self.condition = threading.Condition()
        self.stop_event = threading.Event()
        self.finished = False
        self.sequence = 0
        self.packet = None
        self.thread = threading.Thread(target=self._run, name='latest-camera-frame', daemon=True)
        self.thread.start()

    def _run(self):
        try:
            while not self.stop_event.is_set():
                success, frame = self.capture.read()
                if not success:
                    break
                with self.condition:
                    self.sequence += 1
                    self.packet = (self.sequence, time.monotonic(), frame)
                    self.condition.notify_all()
        finally:
            self.capture.release()
            with self.condition:
                self.finished = True
                self.condition.notify_all()

    def read(self, after_sequence, timeout=2):
        deadline = time.monotonic() + timeout
        with self.condition:
            while self.sequence <= after_sequence and not self.finished:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self.condition.wait(remaining)
            return self.packet if self.sequence > after_sequence else None

    def close(self):
        self.stop_event.set()
        self.thread.join(timeout=2)


class SceneChangeGuard:
    def __init__(self):
        self.previous = None
        self.histogram = None

    def update(self, frame, motion=None):
        small = cv2.cvtColor(cv2.resize(frame, (64, 36)), cv2.COLOR_BGR2GRAY)
        histogram = cv2.calcHist([small], [0], None, [32], [0, 256])
        cv2.normalize(histogram, histogram, norm_type=cv2.NORM_L1)
        changed = False
        if self.previous is not None:
            previous = self.previous
            valid = np.ones(small.shape, np.uint8)
            if motion is not None:
                scale = np.diag([64/frame.shape[1], 36/frame.shape[0], 1.])
                transform = (scale @ np.vstack([motion, [0, 0, 1]]) @ np.linalg.inv(scale))[:2]
                previous = cv2.warpAffine(previous, transform, (64, 36))
                valid = cv2.warpAffine(valid, transform, (64, 36))
            difference = cv2.absdiff(small, previous)[valid > 0]
            histogram_change = cv2.compareHist(histogram, self.histogram, cv2.HISTCMP_BHATTACHARYYA)
            changed = (difference.size > 64 and float(difference.mean()) > 35
                       and float((difference > 40).mean()) > .55 and histogram_change > .35)
        self.previous = small
        self.histogram = histogram
        return changed


class CameraMotion:
    """Estimate previous-to-current background motion, ignoring HUD and bodies."""
    def __init__(self):
        self.previous = None
        self.previous_mask = None
        self.last_quality = 0.

    def update(self, frame, boxes=()):
        height, width = frame.shape[:2]
        size = (480, max(1, round(height * 480 / width)))
        gray = cv2.cvtColor(cv2.resize(frame, size), cv2.COLOR_BGR2GRAY)
        mask = np.full(gray.shape, 255, np.uint8)
        h, w = gray.shape
        mask[:int(h*.16)] = 0
        mask[int(h*.82):] = 0
        mask[int(h*.45):, int(w*.10):int(w*.50)] = 0
        for box in boxes:
            x1,y1,x2,y2 = np.asarray(box[:4]) * [w/width,h/height,w/width,h/height]
            cv2.rectangle(mask, (max(0,int(x1)-8),max(0,int(y1)-8)),
                          (min(w-1,int(x2)+8),min(h-1,int(y2)+8)), 0, -1)
        previous, previous_mask = self.previous, self.previous_mask
        self.previous, self.previous_mask = gray, mask
        self.last_quality = 0.
        if previous is None or previous.shape != gray.shape:
            return None
        points = cv2.goodFeaturesToTrack(previous, maxCorners=160, qualityLevel=.015,
                                        minDistance=9, mask=previous_mask, blockSize=5)
        if points is None or len(points) < 16:
            return None
        current, status, _ = cv2.calcOpticalFlowPyrLK(previous, gray, points, None,
            winSize=(25,25), maxLevel=4, criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,20,.03))
        if current is None:
            return None
        backward, back_status, _ = cv2.calcOpticalFlowPyrLK(gray, previous, current, None,
            winSize=(25,25), maxLevel=4, criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,20,.03))
        if backward is None:
            return None
        good = ((status.ravel() > 0) & (back_status.ravel() > 0)
                & (np.linalg.norm((backward-points).reshape(-1,2),axis=1) < 1.5))
        old, new = points.reshape(-1,2)[good], current.reshape(-1,2)[good]
        if len(old) < 16:
            return None
        matrix, inliers = cv2.estimateAffinePartial2D(old,new,method=cv2.RANSAC,
            ransacReprojThreshold=2.5,maxIters=700,confidence=.99)
        if matrix is None or inliers is None or not np.isfinite(matrix).all():
            return None
        quality = float(inliers.mean())
        selected = old[inliers.ravel().astype(bool)]
        if quality < .55 or len(selected) < 16 or np.ptp(selected[:,0]) < w*.25:
            return None
        zoom = float(np.hypot(matrix[0,0],matrix[0,1]))
        angle = abs(float(np.degrees(np.arctan2(matrix[1,0],matrix[0,0]))))
        if not .8 <= zoom <= 1.25 or angle > 15 or abs(matrix[0,2]) > w*.35 or abs(matrix[1,2]) > h*.35:
            return None
        scale = np.diag([width/w,height/h,1.])
        self.last_quality = quality
        return (scale @ np.vstack([matrix,[0,0,1]]) @ np.linalg.inv(scale))[:2].astype(np.float32)


@contextmanager
def single_camera_instance():
    handle = None
    kernel = None
    if os.name == 'nt':
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        kernel.CreateMutexW.restype = ctypes.c_void_p
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel.CloseHandle.restype = ctypes.c_bool
        ctypes.set_last_error(0)
        handle = kernel.CreateMutexW(None, False, 'Local\\DeadlockGPUCameraDetector')
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        if ctypes.get_last_error() == 183:
            kernel.CloseHandle(handle)
            raise RuntimeError('The detector is already running. Press Q in its preview before starting another copy.')
    try:
        yield
    finally:
        if handle:
            kernel.CloseHandle(handle)
